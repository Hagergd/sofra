import "./inputmask.js";

const inputmask = window.Inputmask;
window.Inputmask = undefined;
export default inputmask;